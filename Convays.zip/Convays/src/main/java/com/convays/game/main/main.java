package com.convays.game.main;

import static com.convays.game.domain.Field.isAlive;
import static com.convays.game.domain.Field.isDead;
import static com.convays.game.domain.Field.mapToSign;
import static com.convays.game.domain.Field.toAliveField;
import static com.convays.game.domain.Field.toDeadField;
import static com.convays.game.domain.Gameboard.initRandomGame;
import static com.convays.game.domain.Gameboard.livingNeighboursIn;
import static com.convays.game.domain.LambdaPredicateExtension.and;
import static com.convays.game.domain.LambdaPredicateExtension.or;
import static com.convays.game.domain.LambdaPredicateExtension.which;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.convays.game.domain.Field;

public class main {
	public static void main(String[] args) throws InterruptedException {

		int xSize = 30;
		int ySize = 20;
		int count =1;

		List<Field> gameboard = initRandomGame(xSize, ySize);

		while (xSize> ySize) {

			// @formatter:off
		    System.out.println("Iteration:"+count);
		    gameboard.stream()
		    	.collect(groupBy(Field::getY, mapToSign()))
				.entrySet()
				.stream()
				.sorted(byYCoord())
				.map(toSingleLine())
				.map(createTextLine())
				.peek(System.out::println)
				.collect(Collectors.toList());
		    
		    gameboard = iterateGameboard(gameboard);

			System.out.println();
			Thread.sleep(1000);
			ySize++;
			count++;
		}
	}

	private static List<Field> iterateGameboard(List<Field> gameboard) {
		
		return gameboard
				.stream()
	    		.map(toDeadField(which(isAlive(), and(), 
		    			which(hasLessThanTwo(livingNeighboursIn(gameboard)), or(), hasMoreThanThree(livingNeighboursIn(gameboard))))))
	    		.map(toAliveField(which(isDead(), and(), hasExactThree(livingNeighboursIn(gameboard)))))
	    		.collect(Collectors.toList());
		
	}

	private static Comparator<Entry<Integer, List<String>>> byYCoord() {
		return (entry1, entry2) -> Integer.compare(entry1.getKey(), entry2.getKey());
	}

	private static Function<Entry<Integer, List<String>>, List<String>> toSingleLine() {
		return (entry) -> entry.getValue();
	}

	private static Collector<Field, ?, Map<Integer, List<String>>> groupBy(Function<Field, Integer> supplier,
			Function<Field, String> mapper) {
		return Collectors.groupingBy(supplier, Collectors.mapping(mapper, Collectors.toList()));
	}

	private static Function<List<String>, String> createTextLine() {
		return (list) -> list.stream().collect(Collectors.joining(""));
	}

	private static Predicate<Field> hasMoreThanThree(Function<Field, List<Field>> neighbours) {
		return (field) -> neighbours.apply(field).size() > 3;
	}

	private static Predicate<Field> hasExactThree(Function<Field, List<Field>> neighbours) {
		return (field) -> neighbours.apply(field).size() == 3;
	}

	private static Predicate<Field> hasLessThanTwo(Function<Field, List<Field>> neighbours) {
		return (field) -> neighbours.apply(field).size() < 2;
	}

}
