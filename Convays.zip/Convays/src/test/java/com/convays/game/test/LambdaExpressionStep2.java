package com.convays.game.test;

import static org.junit.Assert.assertEquals;

import java.util.Objects;
import java.util.function.Predicate;

import org.junit.Test;

public class LambdaExpressionStep2 extends LambdaExpressionRefactoringBase {

	@Test
	public void testLambdaFilterWithEqual() {
	
		String result = BEGRIFF_LISTE
				.stream()
				.filter(equal(FILTER_VALUE))
				.findFirst()
				.get();
		
		assertEquals(FILTER_VALUE, result);
	}
	
	private static <T> Predicate<T> equal(T filter) {
		return (value) -> Objects.equals(value, filter);
	}
	
}
