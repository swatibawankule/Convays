package com.convays.game.test;

import java.util.function.Function;
import java.util.function.Predicate;

import org.junit.Test;

import com.convays.game.domain.Field;

public class LambdaExpressionStep4 {


	@Test
	public void testMapToDeadFieldWhenAlive() {
		Field field = new Field(1, 1, true);

	}

	private static <F, T> Predicate<F> assertTrue(Function<F, Boolean> supplier) {
		return (value) -> supplier.apply(value);
	}

}
