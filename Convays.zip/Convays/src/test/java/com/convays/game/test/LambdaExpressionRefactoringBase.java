package com.convays.game.test;

import java.util.Arrays;
import java.util.List;

public class LambdaExpressionRefactoringBase {

	public static String ZEBRA = "Zebra";
	public static String APFEL = "Apfel";
	public static String BIRNE = "Birne";
	public static String DOJO = "Dojo";
	public static String WEIHNACHTEN = "Weihnachten";

	public static List<String> BEGRIFF_LISTE = Arrays.asList(ZEBRA, APFEL, BIRNE, DOJO, WEIHNACHTEN);
	public static List<Pattern> BEGRIFF_OBJEKT_LISTE = Arrays.asList(new Pattern(ZEBRA), new Pattern(APFEL),
			new Pattern(BIRNE), new Pattern(DOJO), new Pattern(WEIHNACHTEN));

	public static String FILTER_VALUE = WEIHNACHTEN;

}
