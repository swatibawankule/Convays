package com.convays.game.test;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.convays.game.domain.Field;

public class LambdaExpressionStep5 {

	private static Field FIELD00 = new Field(0, 0, false);
	private static Field FIELD01 = new Field(0, 1, true);
	private static Field FIELD02 = new Field(0, 2, true);
	private static Field FIELD11 = new Field(1, 1, true);
	private static Field FIELD10 = new Field(1, 0, false);
	private static List<Field> GAME = Arrays.asList(FIELD00, FIELD01, FIELD02, FIELD11, FIELD10);


	@Test
	public void testGetNeighboursInGame() {
	
	}


}
