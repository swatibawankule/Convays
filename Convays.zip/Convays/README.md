Conway's game of life in einer funtionalen Variante.

Einfach klonen und starten. Nur Java 8 Boardmittel und Junit werden als Abhängigkeiten benötigt.

Die Tests bilden die Basis um die Technik zu erlernen. In den ersten drei Tests wird mit der Filter API der Java 8 Stream gespielt, in Test 4 und 5 müssen die ersten Funktionen für das Game of life implementiert werden.

Viel Spass.